Pixels
======

A stupid but fun Apple ][ simulation created with help of LiveCode.

This version of Pixels is built with LiveCode Community version 6.1.X
Download this free version of LiveCode from http://livecode.com/

2013-12-26

New version of Pixels that works with both on desktop (Mac, Windows, Linux, Raspberry pi) and on mobile devices.
Tested device with Pixels is Nexus 7. 

2013-12-27

New version of Pixels that is resolution independent. Means it will work on any mobile device as Nexus 4,7,10 ,iPhone 4/5c/s or iPad's.
Tested with simulators for all Android platforms. Cannot garantee it will scale correct on iPhone or iPad just yet but it should work.

Added icon's folder if you want to compile for your Android unit.

2013-12-28

Added better graphics for start button and also some sound effects when pressing button and sound when demo has finished. 

Todo:

Add icons for iOS and make sure Pixels work on iOS 7 correctly.