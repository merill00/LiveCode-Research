For loading binary data example:
--------------------------------

sqlldr userid=rest_data/oracle@ORCLPDB1 control=S_COUNTRY_FLAGS_DATA_TABLE.ctl log=/tmp/ulf.log
