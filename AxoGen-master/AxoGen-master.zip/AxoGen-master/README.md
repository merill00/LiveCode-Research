# AxoGen
A livecode tech demo that shows a proof of concept of using mobile sensors for generating a random seed.
## Screenshots
<img src="https://raw.githubusercontent.com/Majed6/AxoGen/master/screenshots/Screenshot_20161218-182500.png" height="500">
<img src="https://raw.githubusercontent.com/Majed6/AxoGen/master/screenshots/Screenshot_20161218-182510.png" height="500">
<img src="https://raw.githubusercontent.com/Majed6/AxoGen/master/screenshots/Screenshot_20161218-182518.png" height="500">
<img src="https://raw.githubusercontent.com/Majed6/AxoGen/master/screenshots/Screenshot_20161218-182631.png" height="500">
<img src="https://raw.githubusercontent.com/Majed6/AxoGen/master/screenshots/Screenshot_20161218-182640.png" height="500">
