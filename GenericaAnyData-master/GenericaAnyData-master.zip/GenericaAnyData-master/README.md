# GenericaAnyData
Livecode Recreation of Galactica-Anno-Dominari

Original Source Code and Mac Xcode Project by Ed Zavata can be found here

https://github.com/ezavada/galactica-anno-dominari-3

The original website can be found here:

http://www.annodominari.com/

This is a preview of the current Livecode Stack

![genericaanydatauipreview04042018a](https://user-images.githubusercontent.com/238475/38341705-2c504fc6-3837-11e8-9776-4cd05bf9ac2d.png)
