LiveCode-MariaDB/MySQL HTTPS API Solution/Demo
Version 1.1.4
Copyright (c) 2016 HostM Web Hosting
https://www.hostm.com/

Feel free to use any or all of the code from these files in your projects. See license.txt for more details.

Instructions on how to use these files can be found at:

https://www.hostm.com/tutorials/livecode/api-mariadb-mysql
