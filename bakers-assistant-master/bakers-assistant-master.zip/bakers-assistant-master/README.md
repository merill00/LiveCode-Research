bakers-assistant
=====================

# Baker's Assistant

Baker's Assistant is a plugin for [LiveCode](https://www.livecode.com) that helps you with your Levure application development.
