# LCDropboxLibrary
LiveCode's New library for talking to dropbox.  Uses the v2 API.  Included with LC 9.0-dp7 and up.
I put it here in case you want to include it with your app in LC 8.
I also have had some cases where I've proposed a patch, and therefore deployed it before LC has.
LC has a version of this at https://github.com/livecode/livecode/blob/develop/extensions/script-libraries/dropbox/dropbox.livecodescript
