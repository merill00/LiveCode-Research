This "program_folder" contains files and folders the program uses.
Do not change the name of this folder.
Do not do anything with these files and folders.
Changing them may cause the program to fail.
