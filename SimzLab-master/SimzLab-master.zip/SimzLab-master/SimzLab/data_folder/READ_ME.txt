When you work in the Lab,
session folders will be written here
and will contain data you save to disk, your
Note Pad, and your Budget Report for quizzes.