# lcw_Tools

This project is designed to contain a minimal set of tools that make the LCW environment functional. This includes the menu tools, the IDE hacks and the script exporting functionality.

This is work-in-progress, as at the moment the base "lcw" project has grown to include these elements. Over time we will migrate the code from the [LCW Project](http://lcw-tools.project.livecode.world/view/welcome-visitors) here.
