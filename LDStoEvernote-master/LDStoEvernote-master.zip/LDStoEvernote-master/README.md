# LDStoEvernote
Livecode stack which takes LDS.org downloaded notes/tags in XML format and converts to an Evernote export file that can be imported into Evernote.
