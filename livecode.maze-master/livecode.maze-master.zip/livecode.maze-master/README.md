# livecode.maze
Mazegenerator and solver build with LiveCode

Alpha version, not working and under construction. Hobby project learning some deaph-first and simple AI.
