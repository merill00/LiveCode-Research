# lc-misc
Miscellaneous LiveCode Projects or Snippets 
