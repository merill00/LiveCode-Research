DropBox API v2 Library
v2.2  Dec 30 2017

--doesn't include business pro API

--OAuth 2 not included since tokens are easily obtained from apps via https://www.dropbox.com/developers/apps

Livecode library for the dropbox v2 API

v2.1 Dec 29 2017 updates the latest dropbox API for users, file, file requests, file properties and templates and paper.

Note that async is now built in to dropbox for batch versions of copy, move, delete and upload.

Sharing is yet to be updated.

see: https://dropbox.github.io/dropbox-api-v2-explorer/

see: https://www.dropbox.com/developers/documentation/http/documentation
