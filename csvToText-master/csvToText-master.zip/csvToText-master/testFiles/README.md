testFiles

TO DO: WE NEED TO DEVELOP .TXT VERSIONS, WHICH ARE THE RESULTS WE WOULD EXPECT AFTER WE PARSE THE .CSV files


I found the "tests-" files at:
https://forge.ocamlcore.org/plugins/scmgit/cgi-bin/gitweb.cgi?p=csv/csv.git;a=tree;f=tests;h=b8d1a991cf7eb5c2290dc8ec027c0c50261667dc;hb=HEAD

mikey- are from me.
