# CodeTest_FolderStructure
using LiveCode to create a FolderStructure using building tree view widget 
Build a tree view to display file/folder, using LiveCode and the Tree View Widget.

1. User can choose folder
2. List files/folders within directory in treeview
3. User can unfold folder
4. Display file path when selected 
5. Ensure performance is reasonable when pointing to a directory with many subfolder
