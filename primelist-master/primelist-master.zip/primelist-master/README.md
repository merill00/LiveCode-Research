# primelist
Code to return a list of primes in LiveCode
