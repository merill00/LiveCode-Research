# livecode-stat-library
Quartam Statistical Functions Library for LiveCode
